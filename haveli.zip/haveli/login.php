
<html>
<head>
<title>check</title>
</head>
<body>
<?php

$con=mysql_connect("localhost","root","","hotel");
if(!$con)
die ("connection error".mysql_error());
mysql_select_db("hotel",$con);

$r=mysql_query("select * from login where email='".$_REQUEST['email']."' and password='".$_REQUEST['password']."'");
if($rec=mysql_fetch_array($r))
{
	
?>

<script>
alert("do you want to save your password");
location.href="index2.html";
</script>
<?php
}
else
{
	?>

<script>
alert("User name or password does not match")
location.href="index8.html";
</script>
<?php
}

mysql_close($con);

?>
</body>
</html>