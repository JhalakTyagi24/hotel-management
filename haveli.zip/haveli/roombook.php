<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	
	<?php
	$con = mysqli_connect("localhost","root","","hotel");
	if (mysqli_connect_errno())
	  {
	  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	  die();
	  }
	
	$r1=mysqli_query($con, "select * from room where aadhar='".$_REQUEST['aadhar']."'");
	if($xy=mysqli_fetch_array($r1))
	{
		echo "your aadhar is already exist";
	
	?>
	<script>
		alert("enter unique aadhar");
		location.href="index3.html";
		</script>
	
	<?php
	}
	else{
		
		$r = mysqli_query($con, "INSERT INTO room (`name`, `pno`, `aadhar`, `rt`) VALUES ('".$_REQUEST['name']."', '".$_REQUEST['pno']."', '".$_REQUEST['aadhar']."', '".$_REQUEST['rt']."')");
		if(!$r){
			echo("Error description: " . mysqli_error($con));
		}else{
			echo "User added";
		}
		exit;
	}
	?>
</body>
</html>