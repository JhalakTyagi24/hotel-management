<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	
	<?php
	$con = mysqli_connect("localhost","root","","hotel");
	if (mysqli_connect_errno())
	  {
	  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	  die();
	  }
	
	$r1=mysqli_query($con, "select * from signup where email='".$_REQUEST['email']."'");
	if($xy=mysqli_fetch_array($r1))
	{
		echo "please enter unique email id";
	
	?>
	<script>
		alert("enter unique id");
		location.href="index7.html";
		</script>
	
	<?php
	}
	else{
	
		$r = mysqli_query($con, "INSERT INTO signup (`name`, `pno`, `email`, `password`) VALUES ('".$_REQUEST['name']."', '".$_REQUEST['pno']."', '".$_REQUEST['email']."', '".$_REQUEST['password']."')");
		if(!$r){
			echo("Error description: " . mysqli_error($con));
		}else{
			echo "User added";
		}
		exit;
	}
	?>
</body>
</html>